const server = require("./server");
const router = require("./router");
const mainHandler = require("./mainHandler");

let handle = {}
handle["/"] = mainHandler.main;
handle["/index.html"] = mainHandler.main;

server.start(router.route, handle);
