const qs = require("querystring");
const fs = require("fs");

const server = require('./server');

function main(response, postData) {
    console.log("Request handler 'start main' was called.");

    const body = '<!DOCTYPE html>'+
        '<html lang="ja">'+
	'<head>' +
	'<meta charset="UTF-8">'+
	'<title></title>' +
	'<meta name="description" content="test">' +
	'<meta name="keywords" content="test">' +
        '<meta http-equiv="content-type" content="text/html; charset=UTF-8">'+
	'</head>' +
        '<body>' +
	'hello world' +
        '</body>'+
        '</html>';

    response.writeHead(200, {"Content-Type": "text/html"});
    response.write(body);
    response.end();
}

exports.main = main;
