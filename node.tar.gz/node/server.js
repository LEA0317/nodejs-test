const settings = require('./settings');

const http = require('http');
const fs = require('fs');
const url = require('url');

function start(route, handle) {
    function onRequest(request, response) {
        switch(request.url) {
	case '/':
	case '/index.html':
	    {
                let postData = '';
                const pathname = url.parse(request.url).pathname;
                console.log("Request for " + pathname + " received.");

                request.setEncoding("utf8");

                request.addListener("data", function(postDataChunk) {
                    postData += postDataChunk;
                    console.log("Received POST data chunk '"+
                                postDataChunk + "'.");
                });

                request.addListener("end", function() {
                    route(handle, pathname, response, postData);
                });
                break;
	    }
	default:
	    {
		response.end();
	    }
	}
    };
	
    const server = http.createServer();
    server.on('request', onRequest);
    server.listen(settings.port, settings.host);
    console.log("Server has started.");
}

exports.start = start;
