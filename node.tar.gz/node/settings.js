// setting for docker
exports.port = 3000;
exports.host = '172.17.0.2';
